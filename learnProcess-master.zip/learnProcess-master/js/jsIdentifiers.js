let lastname, lastName;
LastName = "Haggai";
lastName = "Patrick";
document.getElementById("name").innerHTML=LastName ;
document.getElementById("changeh4").innerHTML="money sweet die";
let x, y, z;
x = 5;
y = x + 5;
z = " The answer is "
document.getElementById("demo").innerHTML=z+y;