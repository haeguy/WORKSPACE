// let x, y;
// x = 5;
// y = 6;
// document.getElementById("demo").innerHTML=x+y;
var x, y;
x = 5;
y = 6;
document.getElementById("demo").innerHTML=x+y;
var z;
z = 5;
document.getElementById("demo2").innerHTML=z*10
var g,h;
g = 5 + 6;
h = g*10;
document.getElementById("demo3").innerHTML=g*10 
